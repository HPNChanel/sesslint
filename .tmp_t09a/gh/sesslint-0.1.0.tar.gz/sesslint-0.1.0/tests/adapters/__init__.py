"""Tests for format adapters."""
